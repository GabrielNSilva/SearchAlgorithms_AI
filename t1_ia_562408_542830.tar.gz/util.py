PRINT_ATIVO = True
PRINT_ATIVO = False

def printif(string=''):
    if PRINT_ATIVO:
        print(string)
